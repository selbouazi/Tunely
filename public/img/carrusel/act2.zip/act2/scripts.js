function crearArrayAleatorio(x) {
    const arr = [];
    for (let i = 0; i < x; i++) {
        const num = Math.floor(Math.random() * (100 - 10 + 1)) + 10;
        arr.push(num);
    }
    return arr;
}


let a = crearArrayAleatorio(10);

function random_rgba() {
    var o = Math.round,
        r = Math.random,
        s = 255;
    return 'rgba(' + o(r() * s) + ',' + o(r() * s) + ',' + o(r() * s) + ',' + r().toFixed(1) + ')';
}

function DibujarGrafico(i) {
    const canvas = document.getElementById("myCanvas");
    const ctx = canvas.getContext("2d");

    const maxW = canvas.width;
    const maxH = canvas.height;

    const margenSuperior = 40;
    const margenInferior = 40;
    const margenIzquierdo = 40;
    const margenDerecho = 40;

    const wDisponible = maxW - margenIzquierdo - margenDerecho;
    const w = wDisponible / a.length;

    const hDisponible = maxH - margenSuperior - margenInferior;
    const variableH = hDisponible / Math.max(...a);
    const h = a[i] * variableH;

    const x = margenIzquierdo + i * w;
    const y = maxH - margenInferior - h;

    var color = random_rgba();
    ctx.fillStyle = color;
    ctx.fillRect(x, y, w, h);
}

function consegirMasGrande() {
    let valorMasgrande = a[0];
    for (let i = 0; i > a.length; i++) {
        if (a[i] > valorMasgrande) {
            valorMasgrande = a[i];
        }
    }
    return valorMasgrande;
}

let multiplicador = consegirMasGrande() / 7;


function generarArray() {
    let valorNumeros = [];
    for (let i = 0; i < 8; i++) {
        valor = multiplicador * i;
        valorNumeros[i] = Math.round(valor);
    }

    return valorNumeros;
}


for (let i = 0; i < a.length; i++) {
    DibujarGrafico(i);
}


const canvas = document.getElementById("myCanvas");
const ctx = canvas.getContext("2d");

ctx.font = "bold 24px serif";
ctx.fillText("Grafic de Barres Dinàmic", canvas.width - (canvas.width * 0.63), canvas.height - (canvas.height * 0.015));